import { useState } from "react";
import axios from "axios";

const ContactForm = ({ selectedUser, onFormSubmit }) => {
  const [email, setEmail] = useState(selectedUser?.email || "");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true);
    setSuccess("");
    setError("");

    try {
      // PUT request (update email)
      const putRequest = axios.put(
        `http://localhost:3000/contacts/${selectedUser.id}`,
        { email: email }
      );

      // POST request (log)
      const postRequest = axios.post("http://localhost:3000/logs", {
        message: "Email updated",
      });

      // Promise.all
      const [putRes, postRes] = await Promise.all([
        putRequest,
        postRequest,
      ]);

      setSuccess("Email updated successfully!");
      onFormSubmit(); // refresh data
    } catch (err) {
      setError("Failed to update email");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {/* Loading */}
      {loading && <p>Loading...</p>}

      {/* Success */}
      {success && <p style={{ color: "green" }}>{success}</p>}

      {/* Error */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      <form onSubmit={handleSubmit}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button type="submit">Update Email</button>
      </form>
    </div>
  );
};

export default ContactForm;