import { useEffect, useState } from "react";
import axios from "axios";
import ContactForm from "./ContactForm";

function App() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [selectedUserId, setSelectedUserId] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);

  // Fetch contacts
  const fetchContacts = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await axios.get("http://localhost:3000/contacts");
      setContacts(response.data);
    } catch (err) {
      setError("Failed to fetch contacts");
    } finally {
      setLoading(false);
    }
  };

  // useEffect (on load)
  useEffect(() => {
    fetchContacts();
  }, []);

  // Handle user select
  const handleUserSelect = (user) => {
    setSelectedUserId(user.id);
    setSelectedUser(user);
  };

  return (
    <div>
      <h2>Contacts</h2>

      {/* Loading */}
      {loading && <p>Loading contacts...</p>}

      {/* Error */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Contact List */}
      <ul>
        {contacts.map((contact) => (
          <li
            key={contact.id}
            onClick={() => handleUserSelect(contact)}
            style={{
              cursor: "pointer",
              fontWeight:
                selectedUserId === contact.id ? "bold" : "normal",
            }}
          >
            {contact.name} - {contact.email}
          </li>
        ))}
      </ul>

      {/* Show form only if user selected */}
      {selectedUser && (
        <ContactForm
          selectedUser={selectedUser}
          onFormSubmit={fetchContacts}
        />
      )}
    </div>
  );
}

export default App;